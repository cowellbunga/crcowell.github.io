<style>
    .bs-sidebar {
        display: none;
    }

    .map {
        max-width: fit-content;
        margin-left: auto;
        margin-right: auto;
    }

    .map img {
        margin: 36px;
    }
    figure {
        display: inline-block;
        overflow-wrap: anywhere;
    }

    figcaption {
        text-align: center;
        overflow-wrap: anywhere;
        white-space: pre-line;
    }
</style>

## Welcome to my portfolio website!

This website was created to serve as a professional portfolio that highlights the skills and techniques I have learned in the [Master of <br> Geospatial Information Science and Technology (MGIST) program]("https://online-distance.ncsu.edu/program/master-of-geospatial-information-science-and-technology/") at NC State. I have worked with a variety of tools to perform spatial analysis, including ESRI products (arcpy, AGOL, ArcGIS Pro, ArcServer) and open source alternatives (QGIS, geopandas, GRASS). 

This portfolio focuses on four core competencies: **Databases and Database Management**, **Modeling and Analytics**, **Programming**, and **Web Services**. Feel free to explore my chosen examples representing each competency via the navigation bar or the image tiles below.

<div class="map">
    <span>
        <a href="competencies/database">
            <figure>
                <img src="images/flow-chart.png" width="108" alt="demo image"/>
                <figcaption>Databases and
                Database Management</figcaption>
            </figure>
        </a>
        <a href="competencies/modeling">
            <figure>
                <img src="images/data-points.png" width="108" alt="demo image"/>
                <figcaption>Modeling and Analytics</figcaption>
            </figure>
        </a>
        <a href="competencies/programming">
            <figure>
                <img src="images/gears.png" width="108" alt="demo image"/>
                <figcaption>Programming</figcaption>
            </figure>
        </a>
        <a href="competencies/web">
            <figure>
                <img src="images/devices.png" width="108" alt="demo image"/>
                <figcaption>Web Services</figcaption>
            </figure>
        </a>
    </span>
</div>

<hr>

<a href="https://cnr.ncsu.edu/geospatial/">
    <img style="float: right;" src="../../images/ncstate-brick-4x1-red-max.png" alt="ncsu red brick logo" width="1000" height="100"/>
</a>