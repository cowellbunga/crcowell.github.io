<hr>

## **Mobile-Ready, Form-Centric Web Application for Tracking Solar Home System (SHS) Satisfaction and Mini-Grid Interest**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p> 
        For a project, I was tasked with developing a form-centric and mobile-ready web application that included questions that use built-in calculations. The mock scenario for this project was to create a form to gauge interest in solar home system (SHS) adoption and to track satisfaction of existing SHS customers. This web application was hosted publicly using ArcGIS Survey123 and Survey123 Connect was used to customize the application from desktop.
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        The application is designed using Survey123 Connect and the Excel format that the platform follows. <b>Figure 1</b> shows the a sample of the Excel format that the program uses, and <b>Figure 2</b> shows the Survey123 Connect desktop interface. The desktop interface presents a live preview of the survey based on the underlying Excel form to help the designer confirm that the form is functioning as intended. Each question in the form has a type that determines criteria for acceptable answers. Some questions also include logic that alters what the form presents next.
    </p>
    <figure style="text-align: center; font-size: 10px; float: left; margin-left: 1em; margin-top: 1em; margin-right: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_xls.png" alt="Excel form used to create the survey" width="400" />
        <figcaption> Figure 1. The Excel form used to create the survey </figcaption>
    </figure>
    <figure style="text-align: center; font-size: 10px; float: left; margin-left: 1em; margin-right: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_connect.png" alt="Survey123 Connect desktop interface" width="400" />
        <figcaption> Figure 2. The Survey123 Connect desktop interface </figcaption>
    </figure> 
    <p>
        For example, this form includes a user-defined estimation of per-person energy demand in a household, shown in <b>Figure 3</b>. <br><br> This estimate can help households determine the energy demand that their respective members should try to limit themselves to. There are also questions that only appear if the user specifies that their household currently has an SHS. This allows for existing customers to rate their current experience, while also enabling prospective customers to express interest.
    </p>
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-right: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_calc.png" alt="Survey123 Connect desktop interface" width="250" />
        <figcaption> Figure 3. Example calculation based on user input </figcaption>
    </figure> 
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>

<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_agol.png" alt="Web map, form, and feature service of the survey" width="400" />
        <figcaption> Figure 4. The web map, form, and feature service connected to the survey </figcaption>
    </figure>
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_webmap.png" alt="Web map showing response data" width="400" />
        <figcaption> Figure 5. The web map with example response data </figcaption>
    </figure>
    <p>
        The final survey is publicly available and can be filled out by anyone (try it out below!). The form includes contact information and a map so that the survey can track who users are and where they are located. This makes it easier to identify spatial trends in energy demand, SHS prevalence, SHS satisfaction, and community mini-grid development interest. <br><br> The energy demand estimation lets users set household energy demand goals to promote efficiency. The SHS section of the survey provides users with a custom experience based on their own preferences and SHS adoption status. You can try filling out the survey below.
    </p>
</div>
<div style="overflow: hidden; margin-left: 8em; margin-right: 2em;">
    <iframe name="survey123webform" width="500" height="400" frameborder="0" marginheight="0" marginwidth="0" title="SHS Survey" src="https://survey123.arcgis.com/share/35b9f9f61797449ba405a78af0ec5cea" allow="geolocation https://survey123.arcgis.com; camera https://survey123.arcgis.com">
        </iframe>
        <script>var survey123webform = document.getElementsByName('survey123webform')[0];window.addEventListener("message",e=>{if(e.data){var t=JSON.parse(e.data);["survey123:webform:formLoaded","survey123:onFormLoaded"].includes(t.event)&&t.contentHeight&&(survey123webform.parentNode.style.height=t.contentHeight+"px")&&(survey123webform.parentNode.style["padding-bottom"]="unset")}});</script>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        This survey project taught me how to quickly create a user experience that can be managed and published from desktop, but accessed from multiple platforms. It was a great experience to learn how to use a specific form style alongside html code to customize a web survey. <br><br> It would be interesting to expand on this survey by analyzing the data submitted by users to generate statistics. For example, the analysis could use the SHS barcode information to track statistics by SHS model.
    </p>
</div>

</span>
</div>

<hr>

## **Creating a Story Map of Wildlife Encounters Using iNaturalist Data - under construction**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p> 
        For a project, I was tasked with developing a dynamic web application using ArcGIS Story Maps. The goal was to create a visually-appealing web interface that includes basic web page elements and spatial elements, all driven by data. iNaturalist is a rich source of community nature observations that can include contextual information and photography. iNaturalist data is structured well for generating content, so I chose to create a Story Map documenting all of my personal iNaturalist observations up to the project date (2018 to 2022).
    </p>
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        The Story Map is fed by a feature layer of iNaturalist observations. Given that these were all my observations, no data cleaning was necessary. However, it is important to filter for observations that meet criteria as needed (ex: has photo) before implementing the data in a public tool. 
    </p>
    <figure style="text-align: center; font-size: 10px; float: left; margin-left: 1em; margin-top: 1em; margin-right: 1em;">
        <img style="border-radius: 8px;" src="../images/survey123_xls.png" alt="Excel form used to create the survey" width="400" />
        <figcaption> Figure 1.  </figcaption>
    </figure>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/gacha_welcome.png" alt="GACHA web app intro screen" width="320" />
        <figcaption> Figure 2. </figcaption>
    </figure> 
    <p>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    </p>
</div>

</span>
</div>

<hr>

## **GEWA Angler Catch  Hotspot Application (GACHA)**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p> 
        For a project, I was tasked with developing a web application that uses fisheries field data and other contextual layers from the <a href="https://www.nps.gov/gewa/index.htm">George Washington National Monument (GEWA)</a>. The application needed to be hosted on a custom ArcGIS Server instance, with a backend geodatabase hosted via Postgres. <br><br> The goal of this project was to develop a tool that provides anglers with a guide for seeking fishing hotspots for specific species that have been observed in the park. The GEWA Angler Catch Hotspot Application (GACHA) is a web-based mapping application that uses spatial data on fish observations from multiple sources to create insights for anglers using the park.
    </p>
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        The application uses an enterprise database, (<i>GACHA.gdb</i> in <b>Figure 1</b>) to serve an editable gamefish layer as a feature service. The gamefish layer is the base layer that provides users with a list of gamefish in the park. The list of gamefish gives the users a collection of species to target during visits. The server also hosts a geoprocessing service that provides the tool's primary function.
    </p>
    <figure style="text-align: center; font-size: 10px; float: left; margin-left: 1em; margin-bottom: 2em; margin-right: 2em;">
        <img style="border-radius: 8px;" src="../images/gacha_db.png" alt="GACHA geodatbase in catalog" width="300" />
        <figcaption> Figure 1. The geodatabase storing the GACHA data sources </figcaption>
    </figure>
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 2em; margin-bottom: 4em;">
        <img style="border-radius: 8px;" src="../images/gacha_rest.png" alt="GACHA rest services page" width="350" />
        <figcaption> Figure 2. The rest service for the GACHA tool </figcaption>
    </figure>
    <p>
        The geoprocessing service collects iNaturalist community observations of local gamefish species. Then, the user can select a buffer distance for creating zones around  observations of the selected species from the gamefish layer. These gamefish zones are used to create a clipping of the iNaturalist data to provide the user with a set of locations where community observations have been made near research observations. <br><br> The feature server, map server, and geoprocessing server hosted on the project ArcGIS Server instance are all shown in <b>Figure 2</b>.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/gacha_welcome.png" alt="GACHA web app intro screen" width="320" />
        <figcaption> Figure 3. GACHA web application welcome window</figcaption>
    </figure> 
    <p>
        The final web application uses the feature, map, and geoprocessing services hosted via ArcGIS Server to serve the GACHA tool publicly. <b>Figure 3</b> shows the custom welcome window that that each user is greeted with. This window provides a brief overview of the GACHA tool. <br><br> The geoprocessing service is included as the <i>Gamefish Nearby Sightings</i> tool shown in <b>Figure 4</b>, with Dissolve Type, Buffer Distance, and Distance Units as input parameters.
    </p>
    <figure style="text-align: center; font-size: 10px; float: left; margin-right: 1em; margin-left: 1em; margin-top: 2em;">
        <img style="border-radius: 8px;" src="../images/gacha_gp.png" alt="Original HSI map from the latest runs" width="350" />
        <figcaption> Figure 4. GACHA web app geoprocessing service</figcaption>
    </figure>
    <p>
        After selecting their preferences, the user can run the tool to produce a new layer of gamefish zones. Anglers can then review the gamefish species present in each zone to compare with gamefish observations from iNaturalist. The results allow anglers to fish for target species in waterways that have higher concentrations of both community and research observations.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        Moving forward, it would be nice to add more complexity to the geoprocessing service, such that the results are more precise. This could be done using habitat suitability layers and data on known dietary sources of the gamefish so that observations of prey species can be included. It would also be interesting to use data from anglers to validate the tool's suggested fishing zones.
    </p>
</div>

</span>
</div>

