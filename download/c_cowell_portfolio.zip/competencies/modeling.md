<hr>

## **Assessment of Venus Flytrap Sightings and Habitat Suitability**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        The Venus flytrap, or Dionaea Muscipula, is a unique species of carnivorous flora that is endemic to the Carolinas, favoring moist, loamy and/or sandy soils that are often found among Longleaf pine forests. These plants are more likely thrive when unique conditions such as acidic, moist soils and the existence of small-scale wildfires overlap in space. Unfortunately, the species falls victim to poaching and habitat change - this may be the reason for ongoing efforts to have the plant listed as threatened or endangered. <br><br> Researchers and citizen scientists alike stand to benefit from the ground-truthing of habitat extents and the generation of new observations. A custom ArcGIS Toolbox has been developed to enable basic habitat suitability analysis, as well as the comparison of suitable areas, or "hotspots", to locations of recent recorded sightings.
    </p>
</div>

<hr> 

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_data_gui.png" alt="ArcTools custom hotspot selection GUI" width="450" />
        <figcaption> Figure 1. ArcTools user interface for the hotspot analysis </figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_sites_gui.png" alt="ArcTools custom site selection GUI" width="450" />
        <figcaption> Figure 2. ArcTools user interface for the site selection </figcaption>
    </figure>
    <p>
        To support education and research efforts related to flytrap conservation, a geospatial application was developed. This application takes multiple environmental parameters that are clipped to the study extent (North Carolina) and filtered according to optimal Venus flytrap (D. muscipula) habitat conditions. These parameters are constrained and overlaid to produce a “hotspots” layer which indicates areas where there may be more favorable conditions for Venus flytrap populations. <br><br> The program compares these hotspots with recent, research-grade public observation data in an attempt to establish potential field study zones where the species may be thriving. <br><br> The process produces user-defined, mile-distance buffers around each observation point to determine the level of overlap between hotspots and documented populations. The total overlap of hotspots within each respective buffer distance is also summarized in a message. <br><br> The process also outputs a user-defined web page presenting observation points that directly overlap (or using buffers if no direct overlap) with the “hotspots” layer. This web page presents study sites that should be prioritized for near-term field research on known populations (ex: ground-truthing). This summary data acts as a starting point for exploratory researchers seeking to produce more observation data in areas where thriving populations have not yet been recorded.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_map_example.png" alt="Example output map of Venus flytrap hotspots and observations" width="500" />
        <figcaption> Figure 3. Example output maps of flytrap observations and habitats</figcaption>
    </figure> 
    <p>
        <b>Figure 3</b> shows an example output map that provides an visual overview of flytrap observations and their proximity to expected habitat sites. <br><br> The hotspot zones represent areas where users should search for venus flytraps. The tool is designed this way to encourage users to produce more observations via iNaturalist.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        This custom tool allows users to visually explore the relationship between community flytrap observations and locations that expected to be flytrap hotspots. The custom inputs allow the user to focus on specific habitat characteristics over specific timeframes. <br><br> This tool could be further improved by creating an automated request/update feature for updating the input iNaturalist data.
    </p>
</div>

</span>
</div>

<hr>

## **Permanent Homestead Observation and Ranking Tool (PHORT)**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        In recent years, the housing market has been extremely volatile across the US, with prices in the Triangle at sustained all-time highs. Natural and man-made resources are also becoming increasingly more strained in areas with higher population density. The higher demand for resources and shelter can also drive prices higher in suburban, peri-urban, and urban areas. It may be potentially more cost-effective to settle in a rural area where more land is typically available for purchase and the average cost per acre is generally lower. Another benefit that aligns with seeking rural land for a permanent home is that there are programs such as the USDA Single Family Housing Guaranteed Loan Program. <br><br> Due to these circumstances, I decided to seek rural land to build my own homestead, so that I can avoid purchasing an overvalued house with potentially unfavorable rates, and so that I may also take my household resource management into my own hands. <br><br> To maximize the user's chances of receiving financial support from programs like the one from USDA, a spatially explicit methodology is used to evaluate tax parcels for their viability to support a rural homestead. The methodology has been packaged in the Python programming language and named the Permanent Homestead Observation and Ranking Tool (PHORT).
    </p>
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        Once the input datasets are available in the correct locations and formats, the tool can begin the analysis. There are logical checks throughout the process that check for the presence of the input data as well as the results of preprocessing, to prevent both failure and unnecessary processing. The process starts off by taking user preferences which are used to prepare the parcel data and togglable explanatory layers, such as elevation and distance to cropland. <b>Figure 1</b> shows an example of the first stage of the process, where the user sets their preferences, and which are then passed to the preprocessing functions.
    </p>
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/phort_prompt.png" alt="Input prompt for the tool" width="450" />
        <figcaption> Figure 1. Initial prompt to start process </figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/phort_progress_reporting.png" alt="Progress report from processing script" width="450" />
        <figcaption> Figure 2. Python console progress report </figcaption>
    </figure>
    <p>
        After the parcels are filtered according to user preferences, the tool prompts the user for additional preferences that influence how the final score is calculated. First the user determines whether they prefer higher or lower elevations, then the user confirms whether they prefer to be located closer or further from existing crop production. I currently opt for higher elevations and closer proximity to cropland – this seems to be a good proxy for avoiding flood zones while still given some favor to lower, flatter areas that farms typically exist in. <br><br> The other layers are currently preprocessed arbitrarily, with their importance being implied. Public water supply, power lines, and major roads all lend to resource availability especially in cases where the potential for self-sufficiency is limited (ex: no wells to groundwater). The solar radiation and aspect surfaces are both processed to favor flat or Southfacing areas that have high solar photovoltaic potential.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        After all the input layers are preprocessed, the final score surface is calculated by multiplying all the raster surfaces together. This final surface represents the viability of a grid cell to support a self-sufficient homestead on a scale of 0 (no viability) to 1 (perfect viability). The scoring surface is then used in a zonal analysis where the average homestead score is calculated within each parcel based on the mean score of contained pixels.
    </p>
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/phort_map.png" alt="Map resulting from viability analysis" width="450" />
        <figcaption> Figure 3. Map of NC with homestead score surface</figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/phort_example.png" alt="Example tax parcel with viability score" width="450" />
        <figcaption> Figure 4. Sample of tax parcels with scores</figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: left; margin-right: 1em; margin-left: 1em; margin-top: 4em;">
        <img src="../images/phort_legend.png" alt="Legend for viability score" width=200 />
        <figcaption> Figure 5. Legend for the homestead score</figcaption>
    </figure> 
    <p>
        <b>Figure 4</b> shows an example tax parcel with its data shown, including the total count of pixels as well as the mean, median, minimum, and maximum scores within the parcel. <br><br> <b>Figure 5</b> represents the legend for the scores shown in <b>Figure 4</b>.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        Creating this scenario allowed me to explore a potential use for custom spatial analyis, for the purpose of acquiring potentially resourceful land. <br><br> While this analysis was applied to a fake scenario, the research performed for it has taught me about land assets and what to look for when purchasing them with self-sufficiency in mind. Ideally this tool could be improved by using field data on the relationship between successful homestead locations and hotspots from the tool. Additional or alternate variables could also be included in the scoring system to improve results.
    </p>
</div>

</span>
</div>