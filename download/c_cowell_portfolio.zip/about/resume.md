
## Summary of Professional Experience
Mr. Cowell is an economist in RTI International’s Center for Applied Economics and Strategy. He supports senior staff in conducting literature reviews; drafting technical documents; producing public-facing summary reports, data analyses, and geospatial analyses; and performing qualitative and quantitative research for nonprofit, private-sector, federal, and international clients. His past work includes data collection and analysis, writing of technical reports, field research of soil and gases, and laboratory research for enzyme and microbial biomass analyses. Mr. Cowell has used statistical software such as Excel to manipulate and analyze datasets. He has also used geographic information software such as ArcGIS and QGIS to perform spatial analyses of geocoded datasets. His research interests include renewable energy, economic development, international development, and the environment.

## Education
BS, Environmental Science (minor in Renewable Energy Assessment), North Carolina State University, Raleigh, NC, 2019.

## Certifications and Licenses
Renewable Energy Technologies Diploma, North Carolina Clean Energy Technology Center, Raleigh, NC, October 2018

## Selected Project Experience
**IDB Groundwater Monitoring Platform in Latin America** (2019 to 2021)—_Data Analyst_.
Provided technical support to the IDB Groundwater Monitoring Platform project, which resulted in a detailed groundwater monitoring platform for aquifers in Latin America. Support included data collection, literature review, and geospatial analysis.

**U.S. Agency for International Development Power Africa, Economic and Geospatial Analysis** (2019 to 2021)—_Geospatial Analyst_.
Provided technical support to the Power Africa Off-Grid Project (PAOP) and the East Africa Energy Project (EAEP). Support included geospatial analysis of potential markets for off-grid electrification, data collection, literature review, and technical writing.

**High-Speed Internet Access in Africa and Asia** (2019 to 2020)—_Technical Writer_.
Provided support for finalizing the reports which outline the results of the econometric analysis involved in this study. Support included data collection and technical writing. 

**Assessing Resilience, Carbon and Water Cycling of Managed and Unmanaged Forests of the U.S. Southeast Coastal Plain in Response to Changes in Hydrology, Extreme Events, and Climate** (2018 to 2019)—_Research Assistant_.
Collected soil samples, soil-gas samples, and temperature readings at research towers in the Alligator River Wildlife Refuge in Plymouth, North Carolina. Conducted recurring analyses of soil samples using mass spectrophotometry. Analyzed soil gasses for methane and carbon quantities using gas concentration analyzers. Assisted postdoctoral research scholars in maintenance of research tower sensors and field-based sensors.

## Professional Experience
* 2019 to date. RTI International, Research Triangle Park, NC.  
    * **Economist 1** (2019 to date). Provides qualitative and quantitative research support to technical documents, public-facing summary reports, and publications. Reviews the technical and professional literature to identify specific findings, build background knowledge, and inform study designs. Conducts data management, analysis, and visualization using Excel, Stata, R, Tableau, ArcGIS, and other tools.
    * **Energy Economics Intern** (May to September 2019). Conducted data collection and analysis, literature reviews, and research pertaining to off-grid renewable energy solutions for underserved countries. Kilowatts to Dollars – LEED IR&D: Researched various off-grid solar technologies and integrated existing geospatial datasets to highlight areas with potential for off-grid solar irrigation implementation in Ethiopia as a solution to support off-grid electrification and development.
* 2018 to 2019. NC State Tree Physiology Lab, Raleigh, NC.   
**Research Assistant.** Conducted field research involving tree coring, gas sampling, research site maintenance. Lab experience included enzyme activity analysis, microbial biomass analysis, cleaning, and solution preparation.
* 2016 to 2018. Digital Cloak, LLC, Stafford, VA.  
**Research/Analyst.** Conducted power plant research by collecting and interpreting data on North Carolina and Virginia power plants. Information later used by the U.S. Department of Defense.

## Computer Skills
* Python
* Bash 
* Git/Github
* Docker
* Kubernetes
* ArcGIS
* QGIS

## Technical Reports
* Fein-Smolinski, B., O'Connor, A. C., Gallaher, M. P., & Cowell, C. R. (2024). Impact analysis of CSIRO residential energy efficiency services. Commonwealth Scientific and Industrial Research Organisation.
* Petrusa, J., Fein-Smolinski, B., Henry, C., Weisberg, S., Cowell, C., & Minor, T. (2024). North Carolina Clean Transportation Study: A community impact assessment of clean transportation policy for medium and heavy-duty trucks in North Carolina. Environmental Defense Fund.
* Hogan, M., Bailey, A., Wilkinson, J., Cowell, C., & Lawrence, S. (2023). What federal funding applications in innovation tell us about the future of economic development in North Carolina. RTI International.
* Love, E., Wood, D. W., Muth, M. K., & Cowell, C. R. (2022). Results of trade model elasticity comparison analysis. USDA Foreign Agricultural Service.
* Cowell, C. R., Gallaher, M. P., Larson, J., & Schwartz, A. (2022). The potential for off-grid solar groundwater irrigation pumping in Sub-Saharan Africa: An exploratory analysis. RTI Press.
