<style>
    .bs-sidebar{
        display: none;
    }
    h1.title{
        display: none;
    }
</style>
<iframe src="https://docs.google.com/forms/d/e/1FAIpQLSefKF1_Ag7mXN-_pDun1w8kudYW4WnGBt9qXeHeKheu5s4QSg/viewform?embedded=true" width="640" height="829" frameborder="0" marginheight="0" marginwidth="0">Loading…</iframe>
