<style>
  .bs-sidebar{
    display: none;
    }
</style>
# About Me

 <p width="200"> <img style="float: right; border-radius: 25px;" src="/images/propic.png" alt="professional photo of me" width="200" /> Hello, my name is Chandler Cowell. <br><br> I am an economist at RTI International and a spatial analytics master's student in my last year of NC State's MGIST program. Welcome to my MGIST portfolio site!<br><br>
 During my undergraduate career, I received my Renewable Energy Technologies Diploma from the NC Clean Technology Center in 2018. I received my bachelor's in Environmental Science with a Renewable Energy Assessment minor from NC State in 2019. <br><br> Just prior to graduation, I joined RTI International as an Energy Economics intern with the Center for Applied Economics and Strategy and I joined as a full-time economist later that year. </p>

[Resume](resume.md)

[Contact Me](contact.md)