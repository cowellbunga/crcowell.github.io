<hr>

## **Scripting the Oyster HSI from Theuerkauf et al. (2019)**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em;">
        <a href="https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0210936"><img style="float: right; border-radius: 8px; margin-right:1em; margin-left:1em; display: inline-block;" src="../images/hsi_paper.png" alt="Theuerkauf et al. (2019) thumbnail" width="260" /></a>
        <figcaption> Figure 1. Theuerkauf et al. 2019 thumbnail </figcaption>
    </figure> 
    <p> 
        As an independent study topic, I took on the responsibility of learning and scripting the North Carolina oyster habitat suitability index (HSI) described in <a href="https://journals.plos.org/plosone/article?id=10.1371/journal.pone.0210936">Theuerkauf et al. (2019)</a>. I worked under the guidance of my project team that included Dr. David Eggleston and Dr. Del Bohnenstiehl from NC State, Dr. Brandon Puckett from the National Oceanic and Atmospheric Administration (NOAA), and Bennett Paradis from the North Carolina Department of Marine Fisheries (NCDMF). <br><br> The goals of this effort were to script and document the HSI process, HSI comparison, and HSI to oyster density comparison to expedite the process and allow for a more streamlined analysis.
    </p>
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        To establish a firm understanding of the concept and application, I reviewed the paper linked in the Problem Description, as well as two other relavant papers. The project team helped me learn the structure of observed oyster data and also helped me understand how the data related to the HSI by testing with updated data alongside historical data for comparison. The team also advised me on the which explanatory variables should or should not be considered.
    </p>
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/hsi_readme_intro.png" alt="ReadMe page introduction" width="450" />
        <figcaption> Figure 2. HSI readme document intro section </figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/hsi_readme_vars.png" alt="ReadMe page variables section sample" width="450" />
        <figcaption> Figure 3. HSI readme document variables section </figcaption>
    </figure>
    <p>
        The exclusionary variables included: bathymetry, bottom type, shellfish leases, nursery areas, military zones, and navigational channels. The threshold variables included: salinity, larval import/export to different habitat types, dissolved oxygen, material stockpile sites, boat ramps, chlorophyll, and flow. <br><br> A data inventory, a ReadMe/user guide (see <b>Figure 2</b> and <b>Figure 3</b>), and a script were packaged to organize the data and analysis into a user-friendly Python environment. The script includes logic to calculate the HSI, but also includes logic to perform further assessments such as HSI to HSI comparisons and relating HSI to oyster density. <br><br> The HSI calculation function within the tool includes two parameters that can be toggled to alter the scope of a specific HSI run: the model focus and the model type. The model can focus on either metapopulation persistence, water filtration, or both. The model type can be null (general), reproduction-based, or time-based.
    </p>
</div>

<hr>


<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/hsi_density_2007-2023.png" alt="HSI compared to oyster density from 2007-2023" width="320" />
        <figcaption> Figure 4. HSI and oyster density relationship</figcaption>
    </figure> 
    <p>
        The results of the process are served via the Python console outputs, output data sheets, and graphs produced by the scripts. The input variables are used by the script to produce HSI estimates that can be compared. <br><br> The comparison function compares two sets of HSI results, which are the oldest and newest result files by default, but both datasets can be specified by the user. For example, the previous HSI run results shown in <b>Figure 5</b> can be compared to the new results shown in <b>Figure 6</b>. <br><br> The script also automates the assessment of the relationship between HSI results and oyster density and an example output from that process is shown in <b>Figure 4</b>.
    </p>
    <figure style="text-align: center; font-size: 10px; float: left; margin-right: 1em; margin-left: 1em;">
        <img src="../images/hsi_map_original.png" alt="Original HSI map from the latest runs" width="300" />
        <figcaption> Figure 5. Map of previous HSI run</figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img src="../images/hsi_map_updated.png" alt="Updated HSI map from the latest runs" width="300" />
        <figcaption> Figure 6. Map of updated HSI run</figcaption>
    </figure> 
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        This project was a great opportunity to learn how spatial tools are developed and used for real-world applications. The project team seems eager to continue developing the tool further to become more data-driven and automated. I hope to continue working with them to make this a reality. It would be very fulfilling for me to assist in making improvements that would influence real-world decisions regarding our State’s critical habitats and natural resources.
    </p>
</div>

</span>
</div>

<hr>

## **Automating Output Visuals for Venus Flytrap observations using Python and HTML**

<hr>

<div class="textbox">
<span>

<p style='margin-top: 1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Problem Description</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p> 
        To streamline the process of producing some visual outputs for my <a href="/competencies/modeling#assessment-of-venus-flytrap-sightings-and-habitat-suitability">Venus Flytrap project</a>, I decided to create a script to automate the process. The project focuses on identifying the overlap between expected Venus flytrap habitats and field observations, to highlight areas where researchers should visit. <br><br> Based on user inputs, contextual visuals need to be produced by the script to show <a href="https://www.inaturalist.org/observations?place_id=30&quality_grade=research&taxon_id=52661">research-grade iNaturalist observations</a> being considered in the analysis. The goal of this effort was to produce a static web page showing flytrap observation images and details for all observations that meet the user-defined criteria.
    </p>
</div>

<hr>

<p style='margin-top: 0.1em; text-align: left; font-size: 20px; margin-left: 1em;'>
    <b>Analysis</b>
</p> 
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_html_gui.png" alt="ArcTools GUI for the process" width="450" />
        <figcaption> Figure 1. ArcTools user interface for static web page generation </figcaption>
    </figure> 
    <figure style="text-align: center; font-size: 10px; float: right; margin-left: 1em; margin-top: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_html_code.png" alt="Python code to create html output" width="500" />
        <figcaption> Figure 2. Python code used to generate static web pages </figcaption>
    </figure>
    <p>
        The process is bundled in within an ArcGIS Toolbox (see <b>Figure 1</b>) to present the user with an easy-to-use graphical interface for setting their desired criteria. <br><br> The primary criteria set by the user are the count of observations and cutoff year. These criteria filter the observations for the user's focus region and limits all outputs to the same scope. <br><br> The script used for automating the static web page generation is shown below in <b>Figure 2</b>.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left: 1em; font-size: 20px;'>
    <b>Results</b>
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <figure style="text-align: center; font-size: 10px; float: right; margin-right: 1em; margin-left: 1em;">
        <img style="border-radius: 8px;" src="../images/flytraps_html_example.png" alt="Web map resulting from ArcServer content" width="450" />
        <figcaption> Figure 3. Example output web page of flytrap observations</figcaption>
    </figure> 
    <p>
        An example output static web page is shown in <b>Figure 3</b>. The process leverages Python to automate the generation of custom html code that is defined by user criteria.
    </p>
</div>

<hr>

<p style='margin-top:0.1em; text-align:left; margin-left:1em; font-size: 20px;'>
    <b>Reflection</b> 
</p>
<div style="overflow: hidden; margin-left: 4em; margin-right: 2em;">
    <p>
        This effort helped me learn how to automate the generation of HTML code using Python. This made it easy to integrate these steps with my existing processes. In the future, it would be nice expand on this by customizing style of the static pages.
    </p>
</div>

</span>
</div>